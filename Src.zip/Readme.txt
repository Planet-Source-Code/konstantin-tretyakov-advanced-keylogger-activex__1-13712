Source to the Keyboard Logger ActiveX control.
Copyright� 2000, Konstantin Tretyakov
kt@smartsite.cjb.net

Visit: http://smartsite.cjb.net

If you use the code in your project, please, give me some credit.
If you manage to improve the code, mail me, please.
I would really appreciate that. Thanx in advance.
